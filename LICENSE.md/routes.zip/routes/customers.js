
/*
 * GET users listing.
 */
var alert = require('alert-node');
exports.list = function(req, res){
    
      req.getConnection(function(err,connection){
           alert(connection);
            var query = connection.query('SELECT * FROM customer',function(err,rows)
            {
                
                if(err)
                {
                    console.log("Error Selecting : %s ",err );
                }
                else
                {
                    var val = req.session.user;
                
                //res.render('customers',{page_title:"Customers - Node.js",data:rows,user:val});

                res.send(rows);
                }
             });
             
             //console.log(query.sql);
        });
      
    };

exports.add = function(req, res){
  res.render('add_customer',{page_title:"Add Customers - Node.js"});
};

exports.edit = function(req, res){
    
    var id = req.params.id;
    
    req.getConnection(function(err,connection){
       
        var query = connection.query('SELECT * FROM customer WHERE id = ',id,function(err,rows)
        {
            
            if(err)
                console.log("Error Selecting : %s ",err );
     
            res.render('edit_customer',{page_title:"Edit Customers - Node.js",data:rows});
                
           
         });
         
         //console.log(query.sql);
    }); 
};

/*Save the customer*/
exports.save = function(req,res){
    
    var input = JSON.parse(JSON.stringify(req.body));
    
    req.getConnection(function (err, connection) {
        
        var data = {
            
            name    : input.name,
            address : input.address,
            password : input.password,
            email   : input.email,
            phone   : input.phone 
        
        };
        var sqlQuery="INSERT INTO customer(name,email,password,address,phone) values('"+
        data.name+"','"+data.email+"','"+data.password+"','"+data.address+"','"+data.phone+"')"
        var query = connection.query(sqlQuery, function(err, rows)
        {
  
          if (err)
              console.log("Error inserting : %s ",err );
         
          res.redirect('/customers');
          
        });
        
       // console.log(query.sql); get raw query
    
    });
};

exports.save_edit = function(req,res){
    
    var input = JSON.parse(JSON.stringify(req.body));
    var id = req.params.id;
    
    req.getConnection(function (err, connection) {
        
        var data = {
            
            name    : input.name,
            address : input.address,
            password : input.password,
            email   : input.email,
            phone   : input.phone 
        
        };
        
        var updateQuery = "Update customer set name = '"+ data.name +"', address = '"+ data.address +
               "', password = '"+ data.password +"', email = '" + data.email + "', phone = '" + data.phone +
                "' where id = " + id;

        connection.query(updateQuery, function(err, rows)
        {
  
          if (err)
              console.log("Error Updating : %s ",err );
         
          res.redirect('/customers');
          
        });
    
    });
};


exports.delete_customer = function(req,res){
          
     var id = req.params.id;
    
     req.getConnection(function (err, connection) {
        
        connection.query("DELETE FROM customer  WHERE id = ? ",[id], function(err, rows)
        {
            
             if(err)
                 console.log("Error deleting : %s ",err );
            
             res.redirect('/customers');
             
        });
        
     });
};


