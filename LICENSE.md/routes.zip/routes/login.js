

  exports.signup = function(req, res) {
        res.render('add_customer',{page_title:"Register Customers - Node.js"});
  };

  exports.signin= function(req, res) {
    res.render('signin',{page_title:"login Customers - Node.js"});
};
